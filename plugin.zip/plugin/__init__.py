import bpy
from pathlib import Path
import os

bl_info = {
    "name": "Import primitives from file",
    "author": "Flor Guilni",
    "version": (0, 1),
    "blender": (2, 79, 0),
    "location": "Add menu -> Mesh -> import from file",
    "description": "Imports objects from a blend file in the same directory as this script",
    "warning": "I don't know what the heck I'm doing",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Object",
    }


class append_model(bpy.types.Operator):
    bl_idname = "object.appendfromfile"
    bl_label = "append object from file"
    bl_options = {'REGISTER', 'UNDO'}
    
    object = bpy.props.StringProperty(name="import_object")
    file = bpy.props.StringProperty(name="import_file")
    
    def execute(self, context):
        bpy.ops.wm.append(
            directory=self.file + "\\Object\\",
            filename=self.object
        )
        return {'FINISHED'}




class INFO_MT_mesh_append_add(bpy.types.Menu):
    bl_idname = "INFO_MT_mesh_append_add"
    bl_label = "add mesh"
    
    def draw(self, context):

        layout = self.layout
        layout.separator()
        
        script_directory = Path(os.path.dirname(os.path.abspath(__file__)))
        blendfile = [str(f) for f in (script_directory.glob("*.blend"))]
        with bpy.data.libraries.load(blendfile[0]) as (blend_from, blend_to):
            for obj in blend_from.objects:
                props = layout.operator("object.appendfromfile", text=obj)
                props.file = blendfile[0]
                props.object = obj
        

def menufunc(self, context):
    layout = self.layout
    layout.separator()
    layout.menu("INFO_MT_mesh_append_add", text="append from file")
    

def register():
    print("registered")
    bpy.utils.register_class(append_model)
    bpy.utils.register_class(INFO_MT_mesh_append_add)
    bpy.types.INFO_MT_mesh_add.append(menufunc)

def unregister():
    bpy.utils.unregister_class(append_model)
    bpy.utils.unregister_class(INFO_MT_mesh_append_add)
    bpy.types.INFO_MT_mesh_add.remove(menufunc)

if __name__ == "__main__":
    register()
